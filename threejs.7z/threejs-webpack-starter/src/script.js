import './style.css'
import * as THREE from 'three'
import * as CANNON from 'cannon-es'
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js'
import { MTLLoader } from 'three/examples/jsm/loaders/MTLLoader.js'
import { OBJLoader} from 'three/examples/jsm/loaders/OBJLoader.js'
import { FBXLoader } from 'three/examples/jsm/loaders/FBXLoader.js'
import { Vec3 } from 'cannon-es'
require('./KeyboardState')

import { TestRoom, ItemSpec } from './testroom.js'

var map = TestRoom;
var specs = ItemSpec;

// Canvas
const canvas = document.querySelector('canvas.webgl')

// Keyboard controller
let keyboard = new KeyboardState();

// Scene
const scene = new THREE.Scene()

// Cannon World
const world = new CANNON.World({
    gravity: new CANNON.Vec3(0, -9.82, 0), // m/s²
});

// single cell size
const CELL_SIZE = 0.1 // 1 UNIT = 1BLOCK

// List of objects to be handle by cannon-es
const physicsObjects = {};

// playerReady flag
let modelReady = false

// Animation mixer
let mixer = new THREE.AnimationMixer()

let lionAnimations = {}
let activeAnim = 'HeadRoll';

let playerObject;

// Possible room items
const items = Object.keys(ItemSpec);

const objMtlPath = 'models/';
const objFbxPath = 'models/';

// sync position and rotation
function syncPhysicsObjects() {
    Object.keys(physicsObjects).forEach((key) => {
        var po = physicsObjects[key];
        var threeObject = po.three;
        var cannonObject = po.cannon;
        
        threeObject.position.copy(cannonObject.position);
        threeObject.quaternion.copy(cannonObject.quaternion);
    });
}

function doAnim(anim = 'HeadRoll') {
    if(activeAnim != anim) {
      lionAnimations[activeAnim].stop();
      activeAnim = anim;
      lionAnimations[anim].play();
    }
}

// ground level plane
const groundBody = new CANNON.Body({
    type: CANNON.Body.STATIC,
    shape: new CANNON.Box(new CANNON.Vec3(1000,1,1000)),
    position: new CANNON.Vec3(0,-1,0)
})
// groundBody.quaternion.setFromEuler(-Math.PI / 2, 0, 0) // make it face up
console.log('GB',groundBody);
world.addBody(groundBody)


const axesHelper = new THREE.AxesHelper(5);
scene.add(axesHelper);
// BLUE = Z
// RED = X
// GREEN = Y


items.forEach((n) => load(n));
loadPlayer();

function load(name) {
    const mtlLoader = new MTLLoader();
    mtlLoader.setPath( objMtlPath );
    mtlLoader.load( name + '.mtl', function( materials ) {
        materials.preload();
        
        const objLoader = new OBJLoader();
        objLoader.setMaterials( materials );
        objLoader.setPath( objMtlPath );
        objLoader.load( name +  '.obj', function ( object ) {
            if(!map[name]) {
                return;
            }

            var box = new THREE.Box3().setFromObject( object );
            const boxdx = Math.round(box.min.x*100)/100;
            const boxdy = Math.round(box.min.y*100)/100;
            const boxdz = Math.round(box.min.z*100)/100;

            map[name].forEach((n, i) => {
                const singleObject = object.clone()

                singleObject.position.x = ( n.x ) * CELL_SIZE - boxdx;  
                singleObject.position.y = ( n.y ) * CELL_SIZE - boxdy;
                singleObject.position.z = ( n.z ) * CELL_SIZE - boxdz;
                
                scene.add( singleObject );

                const newBox = new THREE.Box3().setFromObject( singleObject );
                const dimx = Math.round((newBox.max.x - newBox.min.x)*100)/100;
                const dimy = Math.round((newBox.max.y - newBox.min.y)*100)/100;
                const dimz = Math.round((newBox.max.z - newBox.min.z)*100)/100;
                
                let cannonShape = new CANNON.Box(new CANNON.Vec3(dimx/2, dimy/2, dimz/2));
                
                let cannonBoxPosition = new Vec3(
                    singleObject.position.x,
                    singleObject.position.y,
                    singleObject.position.z
                )

                console.log('SHAPE: ', cannonShape);
                console.log('POSITION: ', singleObject.position);
                
                let cannonBody = new CANNON.Body({
                     position: cannonBoxPosition,
                     quaternion: new CANNON.Quaternion(singleObject.quaternion.x, singleObject.quaternion.y, singleObject.quaternion.z, singleObject.quaternion.w),
                     mass: n.m ? n.m : 1
                });
                cannonBody.addShape(cannonShape);
                world.addBody(cannonBody);

                console.log('CB', cannonBody);

                physicsObjects[name + "" + i] = {three: singleObject, cannon:cannonBody, name: name + "" + i};
            });
        }, onProgress, onError );
    });
}

// function loadPlayer() {
//     const fbxLoader = new FBXLoader();
//     fbxLoader.setCrossOrigin("anonymous");
//     fbxLoader.setPath(objFbxPath);
//     fbxLoader.load('lion_anim.fbx', function (lionmodel) {

//         lionmodel.scale.set(.01,.01,.01);
//         lionmodel.rotateZ(Math.PI/2);
//         mixer = new THREE.AnimationMixer(lionmodel);
//         lionmodel.animations.forEach((a) => {
//             let animationName = a.name;
//             lionAnimations[animationName] = mixer.clipAction(a);
//             console.log('found ' + animationName);
//         });

//         playerObject = lionmodel
//         scene.add(playerObject)
//         modelReady = true

//         const lionShape = new CANNON.Sphere(0.5);
//         const lionBody = new CANNON.Body({mass:1, fixedRotation:true});
//         lionBody.addShape(lionShape);
//         world.addBody(lionBody)

//         physicsObjects['lion'] = {three: playerObject, cannon:lionBody, name: 'lion'};

//         lionAnimations['HeadRoll'].play();

    
//     }, undefined, function(e){console.error(e)});
// }

function loadPlayer() {
    const geometry = new THREE.BoxGeometry( CELL_SIZE, CELL_SIZE, CELL_SIZE );
    const material = new THREE.MeshBasicMaterial( {color: 0xf90000, wireframe:true} );
    const cube = new THREE.Mesh( geometry, material );
    cube.position.x = 10;
    scene.add( cube );


    let cannonShape = new CANNON.Box(new CANNON.Vec3(CELL_SIZE/2, CELL_SIZE/2, CELL_SIZE/2));
    let cannonBody = new CANNON.Body({
        position: new Vec3(cube.position.x, cube.position.y, cube.position.z),
        quaternion: new CANNON.Quaternion(cube.quaternion.x, cube.quaternion.y, cube.quaternion.z, cube.quaternion.w),
        mass: 1
    });
    
    cannonBody.addShape(cannonShape);
    world.addBody(cannonBody);    
    
    physicsObjects['lion'] = {three: cube, cannon:cannonBody, name: 'lion'};
}





var onProgress = function(e) {
    console.log('onprogress', e);
}
var onError = function(e) {
    console.log('onerror',e);
}

// Lights
const pointLight = new THREE.AmbientLight(0xffffff, 0.5)
pointLight.position.y = 20;
scene.add(pointLight)

/**
 * Sizes
 */
const sizes = {
    width: window.innerWidth,
    height: window.innerHeight
}

window.addEventListener('resize', () =>
{
    // Update sizes
    sizes.width = window.innerWidth
    sizes.height = window.innerHeight

    // Update camera
    camera.aspect = sizes.width / sizes.height
    camera.updateProjectionMatrix()

    // Update renderer
    renderer.setSize(sizes.width, sizes.height)
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
})

/**
 * Camera
 */
// Base camera
const camera = new THREE.PerspectiveCamera(90, sizes.width / sizes.height, 0.1, 300)
camera.position.x = 1
camera.position.y = 1
camera.position.z = 1
camera.lookAt(new THREE.Vector3(0,0,0))
scene.add(camera)

// Controls
const controls = new OrbitControls(camera, canvas)
controls.enableDamping = true

/**
 * Renderer
 */
const renderer = new THREE.WebGLRenderer({
    canvas: canvas
});
renderer.setSize(sizes.width, sizes.height)
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 4))

/**
 * Animate
 */
let clock = new THREE.Clock();

const animate = () =>
{
    requestAnimationFrame(animate)

    // Run the simulation independently of framerate every 1 / 60 ms
    world.fixedStep()
    // Update objects
    syncPhysicsObjects();

    if (modelReady) {
        mixer.update(clock.getDelta())
    } 

    // Update Orbital Controls
    controls.update()

    if ( keyboard.pressed("D") ) {
        physicsObjects['lion'].cannon.force = new Vec3(9,0,0);
      }
      if ( keyboard.pressed("A") ) {
        physicsObjects['lion'].cannon.force = new Vec3(-9,0,0);
      }
      if ( keyboard.pressed("W") )  {
        physicsObjects['lion'].cannon.force = new Vec3(0,0,9);
      }
      if ( keyboard.pressed("S") )  {
        physicsObjects['lion'].cannon.force = new Vec3(0,0,-9);
      }
      
      keyboard.update()
        
    // Render
    renderer.render(scene, camera)
}

animate()
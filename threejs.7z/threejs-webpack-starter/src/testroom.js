export const ItemSpec = {
    "5x5x5_axis": {
        bound: { x:5, y:5, z:5 }
    },
    "10x5x15": {
        bound: {x:10, y:5, z:15 }
    }
}

export const TestRoom = {
    "5x5x5_axis": [
        {x:0, y:0, z:0, r:0},
    ],
    // "10x5x15": [
    //     {x:0, y:0, z:5, r:0}
    // ]
}
